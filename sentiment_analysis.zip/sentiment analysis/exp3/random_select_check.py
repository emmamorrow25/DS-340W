import pandas as pd

df = pd.read_csv('random_select_100.csv')

print(df.shape)

