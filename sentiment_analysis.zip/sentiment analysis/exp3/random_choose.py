import pandas as pd
import numpy as np

df = pd.read_csv('SPY_concate_files_Unlabel.csv')

df = df.sample(n=100)

temp = pd.DataFrame()
temp["Sentence"] = df["Sentence"]
temp["valid"] = [0 for i in range(100)]
temp.to_csv("random_select_500.csv")