import pandas as pd
import os

symbol = 'SPY'
source_path = f"{symbol}_concate_files_Unlabel.csv"
for i, chunk in enumerate(pd.read_csv(source_path, chunksize=150000)):
    print(chunk.shape)
    chunk.to_csv('./splits/{}_Unlabel_{}.csv'.format(symbol, i), index=False)