import pandas as pd
import os

symbol = 'SPY'
df = pd.read_csv(f'{symbol}_concat_files.csv')
print(df.shape)
df = df[ df["Sentiment"] != 'None' ]
print(df.shape)
df.to_csv(f'{symbol}_concate_files_User_label.csv')
print("Finish")