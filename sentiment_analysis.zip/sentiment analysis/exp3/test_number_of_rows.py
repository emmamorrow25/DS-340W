import pandas as pd


df = pd.read_csv('./SPY_concat_files.csv')
print(df.shape)